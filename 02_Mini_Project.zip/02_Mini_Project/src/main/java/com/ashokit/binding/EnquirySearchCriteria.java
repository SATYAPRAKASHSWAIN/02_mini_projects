package com.ashokit.binding;

import lombok.Data;

@Data
public class EnquirySearchCriteria {
	private String courseName;
	private String classMode;
	private String enqStatus;
}
