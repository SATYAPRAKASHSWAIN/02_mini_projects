package com.ashokit.controller;

import com.ashokit.binding.LoginForm;
import com.ashokit.binding.SignUpForm;
import com.ashokit.binding.UnlockForm;
import com.ashokit.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;

	@PostMapping("/signup")
	public String handleSignUp(@ModelAttribute("user") SignUpForm form, Model model) {
		boolean status = userService.signup(form);
		System.out.println(status + " chiku");

		if (status) {
			model.addAttribute("succMsg", "Account Created,Check Your Email");
		} else {
			model.addAttribute("errMsg", "Choose unique Email");
		}
		return "signup";

	}

	@GetMapping("/signup")
	public String signupPage(Model model) {
		model.addAttribute("user", new SignUpForm());
		return "signup";
		// return "NewFile.html";

	}

	@GetMapping("/unlock")
	public String unlockPage(@RequestParam String email, Model model) {
		UnlockForm unlockForm = new UnlockForm();
		unlockForm.setEmail(email);

		model.addAttribute("unlock", unlockForm);

		return "unlock";
	}

	@PostMapping("/unlock")
	public String unlockUserAccount(@ModelAttribute("unlock") UnlockForm unlock, Model model) {
		System.out.println(unlock + "satya");
		if (unlock.getNewPwd().equals(unlock.getConfirmPwd())) {
			boolean status = userService.unlockAccount(unlock);
			if (status) {
				model.addAttribute("succMsg", "Your account unlock successfully !!!");

			} else {
				model.addAttribute("errMsg", "Given temporary password is incorrect !!!,check your email ");
			}
		} else {
			model.addAttribute("errMsg", "New Pwd and Comfirm pwd Should be same");
		}
		return "unlock";
	}

	@GetMapping("/login")
	public String loginPage(Model model) {
		model.addAttribute("loginForm", new LoginForm());
		return "login";
	}

	@PostMapping("/login")
	public String login(@ModelAttribute("loginForm") LoginForm loginForm, Model model) {
		System.out.println(loginForm);
		String status = userService.login(loginForm);
		if (status.contains("Success")) {
			// redirect req to dashboard method
			return "redirect:/dashboard";
		}
		model.addAttribute("errMsg", status);
		return "login";
	}

	@GetMapping("/forgot")
	public String forgotPwdPage(Model model) {

		return "forgotPwd";
	}

	@PostMapping("/forgotPwd")
	public String forgotPwd(@RequestParam("email") String email, Model model) {
		System.out.println(email+"email");
		// TODO : Logic
		boolean status = userService.forgotPwd(email);
		System.out.println(status+"status");

		if (status) {
			// sent success message
			model.addAttribute("succMsg", "Pwd sent to your email");
		} else {
			// sent error message
			model.addAttribute("errMsg", "Invalid Email");

		}

		return "forgotPwd";
	}
}
