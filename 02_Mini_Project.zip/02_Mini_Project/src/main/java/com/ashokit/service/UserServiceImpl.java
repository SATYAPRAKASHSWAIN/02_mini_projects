package com.ashokit.service;

import com.ashokit.binding.LoginForm;
import com.ashokit.binding.SignUpForm;
import com.ashokit.binding.UnlockForm;
import com.ashokit.constants.AppConstants;
import com.ashokit.entity.UserDtlsEntity;
import com.ashokit.repository.UserDtlRepo;
import com.ashokit.utility.EmailUtility;
import com.ashokit.utility.PwdUtility;

import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDtlRepo userDtlRepo;

	@Autowired
	private EmailUtility emailUtility;
	
	@Autowired
	private HttpSession httpSession;

	@Override
	public boolean signup(SignUpForm form) {

		UserDtlsEntity user = userDtlRepo.findByemail(form.getEmail());

//        if(user!=null){
//            return false;
//        }


		// todo: Copy data from binding obj to entity obj.
		UserDtlsEntity entity = new UserDtlsEntity();
		BeanUtils.copyProperties(form, entity);

		// ToDo generatoe my random pwd
		String tempPassWord = PwdUtility.generatoeRandomPwd();
		entity.setPwd(tempPassWord);

		// ToDo : set acount status as locked
		//entity.setAccStatus("LOCKED");
		entity.setAccStatus(AppConstants.STR_LOCKED);

		// ToDo : insert email to unlock the account
		userDtlRepo.save(entity);

		// Todo : Sent email to unlock the account
		String to = form.getEmail();
		String subject = AppConstants.UNLOCK_EMAIL_SUBJECT;
		StringBuffer body = new StringBuffer("");
		body.append("<h1> Use below temporary pwd to unlock your account !</h1>");
		body.append("Temporary pwd : " + tempPassWord);
		body.append("<br/>");
		body.append("<a href=\"http://localhost:8080/unlock?email=" + to + "\"> Click Here To Unlock </a>");
		emailUtility.sendEmail(to, subject, body.toString());

		return true;
	}

	@Override
	public boolean unlockAccount(UnlockForm form) {
		UserDtlsEntity entity = userDtlRepo.findByemail(form.getEmail());
		if (entity.getPwd().equals(form.getTempPwd())) {
			entity.setPwd(form.getNewPwd());
			entity.setAccStatus(AppConstants.STR_UNLOCKED);
			userDtlRepo.save(entity);
			return true;
		} else {
			return false;
		}

	}

	@Override
	public String login(LoginForm form) {
		UserDtlsEntity entity = userDtlRepo.findByEmailAndPwd(form.getEmail(), form.getPwd());
//		if (entity == null) {
//			return false;
//		}
//		if(entity.getAccStatus().equals("UNLOCKED")) {
//			return true;
//		}
//		return false;
		if (entity == null) {
			//return "Invalid Credentials";
			return AppConstants.INVALID_CRIDENTIALS_MSG;
		}
		if (entity.getAccStatus().equals(AppConstants.STR_LOCKED)) {
//			return "Your Account Locked !!!";
			return AppConstants.STR_ACC_LOCKED_MSG;
		}
		//create session an store use data in sessio
		httpSession.setAttribute(AppConstants.STR_USER_ID, entity.getUserId());
		
		//return "Success";
		return AppConstants.STR_SUCCESS;
	}

	@Override
	public boolean forgotPwd(String email) {
		// check record presence in db with given email
		UserDtlsEntity entity = userDtlRepo.findByemail(email);

		// if record not available sent error message
		if (entity == null) {
			return false;
		}
		// if record availabe sent pwd to email and send success messgae
		String subject = AppConstants.RECOVER_PWD_EMAIL_SUBJECT;
		String body = AppConstants.RECOVER_PWD_EMAIL_BODY  + entity.getPwd();
		emailUtility.sendEmail(email, subject, body);
		return true;
	}
}
